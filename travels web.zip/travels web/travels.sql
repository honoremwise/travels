-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2018 at 05:50 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travels`
--

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `pic` varchar(250) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` date NOT NULL,
  `siteid` int(11) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `pic`, `userid`, `date`, `siteid`, `description`) VALUES
(2, 'dhhdhdhhdhdhdhd', 'maintenance icon1.jpg', 4, '2018-06-06', 2, 'nhdhdhhhdhdhd');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `site_id` int(11) NOT NULL,
  `site_name` varchar(250) NOT NULL,
  `site_logo` varchar(250) NOT NULL,
  `siteweb_link` varchar(250) NOT NULL,
  `site_email` varchar(250) NOT NULL,
  `site_service_tel` int(11) NOT NULL,
  `user_added_id` int(11) NOT NULL,
  `reg_date` date NOT NULL,
  `latitude` float(10,6) NOT NULL,
  `longitude` float(10,6) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`site_id`, `site_name`, `site_logo`, `siteweb_link`, `site_email`, `site_service_tel`, `user_added_id`, `reg_date`, `latitude`, `longitude`, `status`) VALUES
(1, 'nyungwe', 'honore.PNG', 'www.nyugwe.rw', 'nyungwe@nationalpark.rw', 2147483647, 1, '2018-06-06', -1.970579, 30.104429, 'unpost'),
(2, 'aka', 'sample templete.JPG', 'rwanda.com', 'hdhd', 17852, 4, '2018-06-06', 0.000000, 0.000000, 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `telephone` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `reg_date` date NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `firstname`, `lastname`, `telephone`, `username`, `password`, `user_email`, `reg_date`, `status`) VALUES
(2, 'noella', 'nono', 789456123, 'lolo', 'd6581d542c7eaf801284f084478b5fcc', 'hello@gmail.com', '2018-06-06', 'active'),
(3, 'noellaa', 'nono', 789456123, 'admin', 'fe3691bfbfb168ccadfb74fa1f891583', 'hello1@gmail.com', '2018-06-06', 'active'),
(4, 'stevn', 'gikwerere', 147852, 'gig', '97d6804053f94cbda00ec523d7d6b8a6', 'gsteven@gmail.com', '2018-06-06', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`site_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `site_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
